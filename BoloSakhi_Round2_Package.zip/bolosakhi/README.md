# Bolo Sakhi — Voice-first prototype

A browser prototype for a voice-first assistant in Hindi, Marathi and English. It demonstrates speech recognition, spoken responses, and a local notebook for sales/expenses/reminder notes.

## Run
- Open `index.html` in Chrome (internet may be required for browser speech recognition).
- Allow microphone access.
- Choose Hindi, Marathi or English, then tap **Tap and speak**.
- Example commands: `Aaj 500 rupaye ki sale hui`, `Maine 80 rupaye kharch kiye`, `Remind me to pay rent tomorrow`, or ask about government schemes.
- Quick help tiles also demonstrate actions.

## Limitations
- Speech recognition support depends on browser, device and network; if unavailable, quick-help buttons still demonstrate UI.
- This is a demo, not a production service. Notebook entries are in memory only and are not persisted after page refresh.
- Scheme information is guidance to official sources; the prototype does not validate eligibility or fetch live scheme data.
- No payment, banking or sensitive credential functionality.

## GitHub Pages
1. Create a public GitHub repository named `bolo-sakhi`.
2. Upload `index.html` and this README.
3. Repository Settings → Pages → Deploy from branch → `main` / root.
4. Wait for the published URL and test on mobile Chrome.
